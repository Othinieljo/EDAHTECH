document.addEventListener('DOMContentLoaded', () => {
    AOS.init({
        duration: 1000,
        offset: 200,
        easing: 'ease-in-out',
        once: true,
    });
});